import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class part{
	public static void main(String args[])throws Exception
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		String empno,name,phoneno,address;
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("1.Insert");
			System.out.println("2.Update");
			System.out.println("3.Delete");
			System.out.println("4.Display");
			int n = sc.nextInt();
			switch(n) {
			case 1 :
				Transaction tx = ss.beginTransaction();
				Query q = ss.createQuery("from mypojo");
				
				System.out.println("Insert the values");
				System.out.println("Enter empno");
				empno = sc.next();
				pojo.setEmpno(empno);
				System.out.println("Enter Name");
				name = sc.next();
				pojo.setName(name);
				System.out.println("Enter phoneno");
				phoneno = sc.next();
				System.out.println("Enter address");
				address = sc.next();
			    pojo.setAddress(address);
			    ss.save(pojo);
			    
			    q.setFirstResult(0);
			    q.setMaxResults(10);
			    List list = q.list();
			    System.out.println(list);
			    tx.commit();
			    break;

			case 2: 
				Transaction tx1 = ss.beginTransaction();
				System.out.println("Update row");
				System.out.println("Enter emp no to update");
				empno = sc.next();
				System.out.println("Enter name");
				name = sc.next();
				System.out.println("Enter phone no");
				phoneno = sc.next(); 
				System.out.println("Enter address");
				address = sc.next();
				
				Query q1 = ss.createQuery("update mypojo set name=:n, phoneno=:p,address=:ad where empno=:e"); 
				q1.setParameter("n",name);
				q1.setParameter("p", phoneno);
				q1.setParameter("ad",address);
				q1.setParameter("e",empno);
			
				int status1 = q1.executeUpdate();
				System.out.println(empno + "row updated " + status1);
				tx1.commit();
				break;
				
			case 3:
				Transaction tx2 = ss.beginTransaction();
				System.out.println("Deleting data");
				System.out.println("Enter emp id for deleting ");
				empno = sc.next();
				Query q2 = ss.createQuery("delete from mypojo where empno=:x");
				q2.setParameter("x", empno);
				q2.executeUpdate();
				System.out.println(empno + " row Deleted");
				tx2.commit();
				break;
			case 4:

				Query q3 = ss.createQuery("from mypojo");
				q3.setFirstResult(0);
				q3.setMaxResults(10);
				List stud1 = q3.list();
				System.out.println(stud1);
				Iterator it1 = stud1.iterator();
				while (it1.hasNext()) {
					pojo = (mypojo) it1.next();
					System.out.println("Display Last Entry");
					System.out.println(pojo.getEmpno());
					System.out.println(pojo.getName());
					System.out.println(pojo.getPhoneno());
					System.out.println(pojo.getAddress());
				}
				break;
			case 5:
				System.exit(n);
				break;

			}
      }
	}
}
	


/*

 * create table details1(phoneno varchar2(30),email varchar2(30),password
 * varchar2(30));
 * 
 * insert into details1 values('99887766','sandip@gmail.com','1234')
 * 
 * create table details(rollno varchar2(30),name varchar2(30),address
 * varchar2(30));
 * 
 * insert into details values('101','sandip','bangalore')
 */