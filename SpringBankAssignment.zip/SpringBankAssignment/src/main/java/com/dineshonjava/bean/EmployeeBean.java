package com.dineshonjava.bean;

 //create table bank(name varchar2(30),address varchar2(100),phone number,email varchar2(50),compname varchar2(50),age number,bal number);
public class EmployeeBean {
	private Integer id;
	private String name;
	private String address;
	private Long phone;
	private String email;
	private String compname;
	private Integer age;
	private Long bal;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	} 
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Long getPhone() {
		return phone;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCompname() {
		return compname;
	}
	public void setCompname(String compname) {
		this.compname = compname;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Long getBal() {
		return bal;
	}
	public void setBal(Long bal) {
		this.bal = bal;
	}

	
	
}
